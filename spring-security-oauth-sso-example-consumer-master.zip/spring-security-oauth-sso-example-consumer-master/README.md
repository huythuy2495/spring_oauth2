-spring-security-oauth-sso-example-consumer
===========================================

Example using Spring Security OAuth2 for SSO - Consumer